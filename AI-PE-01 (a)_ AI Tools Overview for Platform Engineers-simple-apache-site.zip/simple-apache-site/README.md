# Simple Apache Site

A basic Apache project for deploying a static site using GitHub Actions CI/CD.
